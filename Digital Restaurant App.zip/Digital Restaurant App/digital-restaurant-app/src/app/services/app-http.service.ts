import { Injectable } from '@angular/core';

import { RequestOptions } from 'https';

@Injectable({
  providedIn: 'root'
})
export class AppHttpService {

  constructor() { }

}